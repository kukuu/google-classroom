<?php
// create a string
$string = 'sex at noon taxes';

// look for a match
echo preg_match("/s.x/", $string, $matches);

?> 