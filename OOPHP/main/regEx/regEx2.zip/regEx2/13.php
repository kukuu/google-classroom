<?php
// create a string
$string = 'php'; 

// look for a match
echo preg_match("/ph*p/", $string, $matches);

?> 