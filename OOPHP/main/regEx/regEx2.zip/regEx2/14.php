<?php
// create a string
$string = 'pp';

// look for a match
echo preg_match("/ph+p/", $string, $matches);

?> 